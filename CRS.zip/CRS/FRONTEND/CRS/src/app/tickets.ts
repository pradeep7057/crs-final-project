export class Tickets {

    public t_NO:number;
    public cust_ID:number;
    public mgr_ID:number;
    public engr_ID:number;
    public pincode:number;
    public complaint:string;
    public status:string;
    constructor(){
        
    }
}
 