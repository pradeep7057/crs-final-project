import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust-service.service';

@Component({
  selector: 'app-searchdelete',
  templateUrl: './searchdelete.component.html',
  styleUrls: ['./searchdelete.component.css']
})
export class SearchdeleteComponent implements OnInit {

  cust:any;
 
  
  constructor(private custsservice:CustService) { }


public delteUser(cust_ID:number){
 //let resp= 
 this.custsservice.deleteUser(cust_ID).subscribe();
// resp.subscribe((data: any)=>this.cust=data);
alert('Data Deleted Successfully')
return location.reload();
}



  ngOnInit() {
    let resp=this.custsservice.showCust();
    resp.subscribe((data)=>this.cust=data);
  }

}
