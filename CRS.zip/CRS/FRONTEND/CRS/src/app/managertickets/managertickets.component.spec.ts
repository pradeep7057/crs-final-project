import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerticketsComponent } from './managertickets.component';

describe('ManagerticketsComponent', () => {
  let component: ManagerticketsComponent;
  let fixture: ComponentFixture<ManagerticketsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerticketsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerticketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
