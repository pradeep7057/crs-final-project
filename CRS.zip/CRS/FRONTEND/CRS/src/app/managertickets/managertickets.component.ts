import { Component, OnInit } from '@angular/core';
import { Tickets } from '../tickets';
import { TicketsService } from '../tickets.service';

@Component({
  selector: 'app-managertickets',
  templateUrl: './managertickets.component.html',
  styleUrls: ['./managertickets.component.css']
})
export class ManagerticketsComponent implements OnInit {
tick : Tickets;
  mgr_ID : number;
  tickets : Tickets [];
  ticketDetails = null as any;
  ticketToUpdate = {
    t_NO:"",
    cust_ID:"",
    mgr_ID:"",
    engr_ID:"",
    pincode:"",
    complaint:"",
    status:""
  };
  ticketsToUpdate: any;
  constructor(private _ticketsservice : TicketsService) { 
    this.mgr_ID = parseInt(localStorage.getItem("mgId"));
    this._ticketsservice.showManagerTickets(this.mgr_ID).subscribe(x => {
      this.tickets=x;
    })
//   
  }

  ngOnInit(): void {
  }

  showtickets() {
    this._ticketsservice.showtickets().subscribe(
      (resp: any) => {
        console.log(resp);
        this.tickets= resp;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  delteUser(t_NO:number) {
    this._ticketsservice.deleteUser(t_NO).subscribe(
      (resp: any) => {
        console.log(resp);
        this.showtickets();
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  edit(tick: any){
    this.ticketToUpdate = tick;
  }

  updateticket(){
    this._ticketsservice.updateticket(this.ticketToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}
