import { Component, OnInit } from '@angular/core';
import { Cust } from '../cust';
import { CustService } from '../cust-service.service';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {

  cust :Cust[];
  custDetails = null as any;
  custToUpdate = {
    cust_ID:"",
    custName:"",
    address:"",
    pincode:"",
    mobileNo:""
  };
  customerToUpdate: any;

  constructor(private custService: CustService) {
    this.showCust();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented');

  }

  showCust() {
    this.custService.showCust().subscribe(
      (resp: any) => {
        console.log(resp);
        this.cust = resp;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

 delteUser(cust_ID:number){
   
    this.custService.deleteUser(cust_ID).subscribe();
    alert(' Deleted Successfully')
 
   return location.reload();
   }

  edit(customer: any){
    this.customerToUpdate = customer;
  }

  updateCustomer(){
    this.custService.updateCustomer(this.customerToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
        alert('Data Updated Successfully')
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}
