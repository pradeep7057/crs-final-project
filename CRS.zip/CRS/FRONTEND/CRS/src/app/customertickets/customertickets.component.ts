import { Component, OnInit } from '@angular/core';
import { Tickets } from '../tickets';
import { TicketsService } from '../tickets.service';

@Component({
  selector: 'app-customertickets',
  templateUrl: './customertickets.component.html',
  styleUrls: ['./customertickets.component.css']
})
export class CustomerticketsComponent implements OnInit {

  cust_ID: number;
  tickets : any;
  constructor(private _ticketsservice : TicketsService) { 
    this. cust_ID = parseInt(localStorage.getItem("custId"));
    this._ticketsservice.showCustomerTickets(this. cust_ID).subscribe(x => {
      this.tickets=x;
    })

  }

  ngOnInit(): void {
  }

}
