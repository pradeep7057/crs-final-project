import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Tickets } from './tickets';
import { Cust } from './cust';

@Injectable({
  providedIn: 'root'
})
export class TicketsService {
  assign(t_NO: number) {
    throw new Error('Method not implemented.');
  }

 

  constructor(private _http: HttpClient) { }

  showtickets(): Observable<Tickets []> {
    return this._http.get<Tickets[]>("http://localhost:8087/tickets")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
 public showManagerTickets(mgr_ID : number): Observable<Tickets []> {
    return this._http.get<Tickets []>("http://localhost:8087/Manager/"+mgr_ID)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
        );
  }
  public showEngineerTickets(engr_ID : number): Observable<Tickets []> {
    return this._http.get<Tickets []>("http://localhost:8087/Engineer/"+engr_ID)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
        );
  }
  public showCustomerTickets(cust_ID : number): Observable<Tickets []> {
    return this._http.get<Tickets []>("http://localhost:8087/Customer/"+cust_ID)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
        );
  }
 
public addtickets(tickets: any){
  return this._http.post("http://localhost:8087/tickets",tickets)
}
public deleteUser(t_NO: number){
  return this._http.delete(`http://localhost:8087/Tickets/${t_NO}`);
 }


public updateticket(tick: any) {
  return this._http.put("http://localhost:8087/tickets",tick);
}
}
