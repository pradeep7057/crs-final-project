import { Engr } from './engr';

describe('Engr', () => {
  it('should create an instance', () => {
    expect(new Engr()).toBeTruthy();
  });
});
