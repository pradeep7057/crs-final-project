import { Component, OnInit } from '@angular/core';
import { Engr } from '../engr';
import { EngrService } from '../engr.service';


@Component({
  selector: 'app-update-engineer',
  templateUrl: './update-engineer.component.html',
  styleUrls: ['./update-engineer.component.css']
})
export class UpdateEngineerComponent implements OnInit {

  engr :Engr[];
  manDetails = null as any;
  engrToUpdate = {
    engr_ID:"",
    engrname:"",
    pincode:"",
    mobileno:""
  };
  engineerToUpdate:any;

  constructor(private engrservice: EngrService) {
    this.showengr();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showengr() {
    this.engrservice.showengr().subscribe(
      (resp: any) => {
        console.log(resp);
        this.engr= resp;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  delteUser(engr_ID:number) {
    this.engrservice.deleteUser(engr_ID).subscribe(
      (resp: any) => {
        console.log(resp);
        this.showengr();
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  edit(engineer: any){
    this.engineerToUpdate = engineer;
  }

  updateCustomer(){
    this.engrservice.updateengineer(this.engineerToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}
