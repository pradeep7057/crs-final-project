import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teammenbers',
  templateUrl: './teammenbers.component.html',
  styleUrls: ['./teammenbers.component.css']
})
export class TeammenbersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
