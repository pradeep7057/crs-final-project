import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeammenbersComponent } from './teammenbers.component';

describe('TeammenbersComponent', () => {
  let component: TeammenbersComponent;
  let fixture: ComponentFixture<TeammenbersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeammenbersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeammenbersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
