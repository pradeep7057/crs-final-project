import { Cust } from './cust';

describe('Cust', () => {
  it('should create an instance', () => {
    expect(new Cust()).toBeTruthy();
  });
});
