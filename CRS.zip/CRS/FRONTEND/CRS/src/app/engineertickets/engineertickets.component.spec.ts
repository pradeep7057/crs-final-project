import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EngineerticketsComponent } from './engineertickets.component';

describe('EngineerticketsComponent', () => {
  let component: EngineerticketsComponent;
  let fixture: ComponentFixture<EngineerticketsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EngineerticketsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EngineerticketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
