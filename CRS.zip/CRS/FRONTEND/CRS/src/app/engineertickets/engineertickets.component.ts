import { Component, OnInit } from '@angular/core';
import { Tickets } from '../tickets';
import { TicketsService } from '../tickets.service';

@Component({
  selector: 'app-engineertickets',
  templateUrl: './engineertickets.component.html',
  styleUrls: ['./engineertickets.component.css']
})
export class EngineerticketsComponent implements OnInit {

  engr_ID : number;
  tickets : Tickets [];
  constructor(private _ticketsservice : TicketsService) { 
    this.engr_ID = parseInt(localStorage.getItem("engId"));
    this._ticketsservice.showEngineerTickets(this.engr_ID).subscribe(x => {
      this.tickets=x;
    })
//    this.orders = this._ordersService.showCOrders(this.customerid);
  }

  ngOnInit(): void {
  }

}
