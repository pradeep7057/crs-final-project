import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Engr } from './engr';

@Injectable({
  providedIn: 'root'
})
export class EngrService {

  constructor(private _http: HttpClient) { }

  showengr(): Observable<Engr []> {
    return this._http.get<Engr[]>("http://localhost:8087/engineers")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  } 
  public updateengineer(engineer: any) {
    return this._http.put("http://localhost:8087/engineers",engineer);
  }
  public create(engineer: any){
    return this._http.post("http://localhost:8087/engineers",engineer)
  }
  public deleteUser(engr_ID: number){
    return this._http.delete(`http://localhost:8087/engineers/${engr_ID}`);
   }
searchengr(eid : number): Observable<Engr> {
  return this._http.get<Engr>("http://localhost:8087/engineers/"+eid)
    .pipe(
      tap(data =>
      console.log('All: ' + JSON.stringify(data)))
    );
}
}