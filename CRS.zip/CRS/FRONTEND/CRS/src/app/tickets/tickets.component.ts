import { Component, OnInit } from '@angular/core';
import { Tickets } from '../tickets';
import { TicketsService } from '../tickets.service';

@Component({
  selector: 'app-tickets',
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.css']
})
export class TicketsComponent implements OnInit {

 ticket : Tickets[]
  ticketDetails = null as any;
  ticketToUpdate = {
    t_NO:"",
    cust_ID:"",
    mgr_ID:"",
    engr_ID:"",
    pincode:"",
    complaint:"",
    status:""
  };
  ticketsToUpdate: any;

  constructor(private ticketsservice: TicketsService) {
    this.showtickets();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  showtickets() {
    this.ticketsservice.showtickets().subscribe(
      (resp: any) => {
        console.log(resp);
        this.ticket = resp;
        
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  delteUser(t_NO:number) {
    this.ticketsservice.deleteUser(t_NO).subscribe();
    alert('Data Deleted Successfully')
    return location.reload();
  
  }

  edit(tick: any){
    this.ticketToUpdate = tick;
  }
  

  updateticket(){
    this.ticketsservice.updateticket(this.ticketToUpdate).subscribe(
      (resp: any) => {
        console.log(resp);
        alert('Status Updated Successfully')
      },
      (err: any) => {
        console.log(err);
      }
    );
  }


}