import { Component, OnInit } from '@angular/core';
import { Mgr } from '../mgr';
import { MgrService } from '../mgr.service';

@Component({
  selector: 'app-mgr-show',
  templateUrl: './mgr-show.component.html',
  styleUrls: ['./mgr-show.component.css']
})
export class MgrShowComponent implements OnInit {


    mgr : Mgr[];
    constructor(private _mgrservice : MgrService) {
      this._mgrservice.showmgr().subscribe({
        next: rs =>{
          this.mgr = rs;
        }
      })
     }
     public delteUser(mgr_ID:number){
      //let resp= 
      this._mgrservice.deleteUser(mgr_ID).subscribe();
     // resp.subscribe((data: any)=>this.cust=data);
     return location.reload();
     }
  
    ngOnInit(): void {
    }
  
  }
