import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Mgr } from './mgr';

@Injectable({
  providedIn: 'root'
})
export class MgrService {

  constructor(private _http: HttpClient) { }

  showmgr(): Observable<Mgr []> {
    return this._http.get<Mgr[]>("http://localhost:8087/managers")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  public create(mgr: any){
    return this._http.post("http://localhost:8087/managers",mgr)
  }

  
  public updatemanager(manager: any) {
    return this._http.put("http://localhost:8087/managers",manager);
  }
  public deleteUser(mgr_ID: number){
    return this._http.delete(`http://localhost:8087/managers/${mgr_ID}`);
   }
  searchmgr(mid : number): Observable<Mgr> {
    return this._http.get<Mgr>("http://localhost:8087/managers/"+mid)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
}