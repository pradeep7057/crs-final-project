export class Mgr {

    public mgr_ID:number;
    public mgrname:string;
    public pincode:number;
    public mobileno: number;
  mgrID: number;

}
