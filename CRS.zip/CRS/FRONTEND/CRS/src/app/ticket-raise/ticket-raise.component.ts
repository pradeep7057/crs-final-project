import { Component, OnInit } from '@angular/core';
import { Cust } from '../cust';
import { Mgr } from '../mgr';
import { Engr } from '../engr';
import { Tickets } from '../tickets';
import { CustService } from '../cust-service.service';
import { MgrService } from '../mgr.service';
import { EngrService } from '../engr.service';
import { TicketsService } from '../tickets.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ticket-raise',
  templateUrl: './ticket-raise.component.html',
  styleUrls: ['./ticket-raise.component.css']
})
export class TicketRaiseComponent implements OnInit {
  addtickets: any;

  constructor(private ticketsservice:TicketsService){}
  register(addtickets:any){
this.ticketsservice.addtickets(addtickets.value).subscribe();
 }
  ngOnInit(): void {
  }

}


